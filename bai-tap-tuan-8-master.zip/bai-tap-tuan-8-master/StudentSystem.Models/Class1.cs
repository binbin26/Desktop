﻿namespace StudentSystem.Models
{
    public class Class1
    {

    }
}
