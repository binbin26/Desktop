﻿namespace StudentSystem.Data
{
    public class Class1
    {

    }
}
